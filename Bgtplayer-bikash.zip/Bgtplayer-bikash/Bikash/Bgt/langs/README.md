# powered By Bikash Halder Or Aditya Halder
# Bangali Language Add By Bikash Halder
# telegram first BENGALI Support Music Bot
[ꜱʀɪᴋᴀɴᴛᴀ](https://t.me/secret_societ)

# **Don't Use Bengali Language Without Credit** 😎😎
